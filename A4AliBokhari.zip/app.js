'use strict'

// C library API
const ffi = require('ffi-napi');

// Express App (Routes)
const express = require("express");
const app     = express();
const path    = require("path");
const fileUpload = require('express-fileupload');
const mysql = require('mysql2/promise');

app.use(fileUpload());
app.use(express.static(path.join(__dirname+'/uploads')));

// Minimization
const fs = require('fs');
const JavaScriptObfuscator = require('javascript-obfuscator');

// Important, pass in port as in `npm run dev 1234`, do not change
const portNum = process.argv[2];
let connection;

// Send HTML at root, do not change
app.get('/',function(req,res){
  res.sendFile(path.join(__dirname+'/public/index.html'));
});

// Send Style, do not change
app.get('/style.css',function(req,res){
  //Feel free to change the contents of style.css to prettify your Web app
  res.sendFile(path.join(__dirname+'/public/style.css'));
});

// Send obfuscated JS, do not change
app.get('/index.js',function(req,res){
  fs.readFile(path.join(__dirname+'/public/index.js'), 'utf8', function(err, contents) {
    const minimizedContents = JavaScriptObfuscator.obfuscate(contents, {compact: true, controlFlowFlattening: true});
    res.contentType('application/javascript');
    res.send(minimizedContents._obfuscatedCode);
  });
});

//Respond to POST requests that upload files to uploads/ directory
app.post('/upload', function(req, res) {
  if(!req.files) {
    return res.status(400).send('No files were uploaded.');
  }

  if (typeof req.files.uploadFile == 'undefined') {
    res.redirect('/');
    return;
  }

  let uploadFile = req.files.uploadFile;

  // Use the mv() method to place the file somewhere on your server
  uploadFile.mv('uploads/' + uploadFile.name, function(err) {
    if(err) {
      return res.status(500).send(err);
    }

    res.redirect('/');
  });
});

//Respond to GET requests for files in the uploads/ directory
app.get('/uploads/:name', function(req , res){
  fs.stat('uploads/' + req.params.name, function(err, stat) {
    if(err == null) {
      res.sendFile(path.join(__dirname+'/uploads/' + req.params.name));
    } else {
      console.log('Error in file downloading route: '+err);
      res.send('');
    }
  });
});

//******************** Your code goes here ********************

let parser = ffi.Library('./libsvgparse', {
  'createValidSVGimage': [ 'pointer', ['string', 'string'] ],
  'SVGtoJSON': [ 'string', [ 'pointer' ] ],
  'deleteSVGimage' : [ 'void', ['pointer'] ],
  'getTitle' : ['string', ['pointer']],
  'getDesc' : ['string', ['pointer']],
  'getRectListJSON' : ['string', ['pointer']],
  'getCircListJSON' : ['string', ['pointer']],
  'getPathListJSON' : ['string', ['pointer']],
  'getGroupListJSON' : ['string', ['pointer']],
  'makeAttr' : ['pointer', ['string', 'string']],
  'setAttribute' : ['void', ['pointer', 'int', 'int', 'pointer']],
  'validateSVGimage' : ['int', ['pointer', 'string']],
  'writeSVGimage' : ['int', ['pointer', 'string']],
  'setTitle' : ['void', ['pointer', 'string']],
  'setDescription' : ['void', ['pointer', 'string']],
  'JSONtoSVG' : ['pointer',['string']],
  'JSONtoRect' : ['pointer', ['string']],
  'JSONtoCircle' : ['pointer', ['string']],
  'createSVG' : ['pointer', []],
  'addComponent' : ['void',['pointer', 'int', 'pointer']],
  'scaleRects' : ['void', ['pointer', 'float']],
  'scaleCircs' : ['void', ['pointer', 'float']]
});

app.get('/images', function(req , res){
  var dict = {};
  var files = fs.readdirSync(__dirname+'/uploads/');
  for (const file of files) {
    let c = parser.createValidSVGimage(__dirname+"/uploads/" + file, __dirname + "/parser/svg.xsd");
    let s = parser.SVGtoJSON(c);
    if (s != "{}") {
      const stats = fs.statSync("uploads/" + file);
      const fileSizeInBytes = stats.size;
      dict[file] = JSON.parse(s);
      dict[file]["size"] = Math.round(fileSizeInBytes / 1000);
    }
    parser.deleteSVGimage(c);
  }
  res.send(dict);
});

app.get('/viewpanel', function(req, res) {
  console.log(req.query.file);
  var image = {};
  let s = parser.createValidSVGimage(__dirname+"/uploads/" + req.query.file, __dirname + "/parser/svg.xsd");
  let c = parser.getTitle(s);
  image["title"] = c;
  c = parser.getDesc(s);
  image["description"] = c;
  c = parser.getRectListJSON(s);
  image["rectangles"] = JSON.parse(c);
  c = parser.getCircListJSON(s);
  image["circles"] = JSON.parse(c);
  c = parser.getPathListJSON(s);
  image["paths"] = JSON.parse(c);
  c = parser.getGroupListJSON(s);
  image["groups"] = JSON.parse(c);
  parser.deleteSVGimage(s);
  res.send(image);
});

app.get('/edit', function(req, res) {
  //console.log(req.query);
  let shape = req.query.shape;
  let shapen = -1;
  if (shape == 'SvgImage') {
    shapen = 0;
  } else if (shape == 'Circle') {
    shapen = 1;
  } else if (shape == 'Rectangle') {
    shapen = 2;
  } else if (shape == 'Path') {
    shapen = 3;
  } else if (shape == 'Group') {
    shapen = 4;
  }
  let img = parser.createValidSVGimage(__dirname + "/uploads/" + req.query.image, __dirname + "/parser/svg.xsd");
  let attr = parser.makeAttr(req.query.name, req.query.value);
  parser.setAttribute(img, shapen, parseInt(req.query.index), attr);
  let valid = parser.validateSVGimage(img, __dirname + "/parser/svg.xsd");
  if (valid == 1) {
    let saved = parser.writeSVGimage(img, __dirname + "/uploads/" + req.query.image);
    parser.writeSVGimage(img, __dirname + "/uploads/" + req.query.image);
    parser.deleteSVGimage(img);
    if (saved == 1) {
      changes(req.query.image, "Add/Edit attribute", req.query.name + ": " + req.query.value + " for " + shape + " " + req.query.index);
      res.send({
        status : 1
      });
    } else {
      res.send({
        status: 0
      });
    }
  } else{
    parser.deleteSVGimage(img);
    res.send ({
      status : 0
    });
  }
});

app.get('/edit-title', function(req, res) {
  let s = parser.createValidSVGimage(__dirname+"/uploads/" + req.query.image, __dirname + "/parser/svg.xsd");
  parser.setTitle(s, req.query.title);
  let saved = parser.writeSVGimage(s, __dirname + "/uploads/" + req.query.image);
  if (saved == 1) {
    res.send ({
      status : 1
    });
  } else {
    res.send ({
      status : 0
    });
  }
  parser.deleteSVGimage(s);
  changes(req.query.image, "update title", "title updated to: " + req.query.title);
});

app.get('/edit-description', function(req, res) {
  console.log(req.query.description);
  let s = parser.createValidSVGimage(__dirname+"/uploads/" + req.query.image, __dirname + "/parser/svg.xsd");
  parser.setDescription(s, req.query.description);
  let saved = parser.writeSVGimage(s, __dirname + "/uploads/" + req.query.image);
  if (saved == 1) {
    res.send ({
      status : 1
    });
  } else {
    res.send ({
      status : 0
    });
  }
  parser.deleteSVGimage(s);
  changes(req.query.image, "update description", "description updated to: " + req.query.description);
});

app.get('/create-file', async function(req, res) {
  var files = fs.readdirSync(__dirname+'/uploads/');
  if(files.includes(req.query.filename)) {
    res.send({
      status: 0
    });
    return;
  }
  let splited = req.query.filename.split(".");
  if (splited[1] != 'svg') {
    res.send({
      status: 0
    });
    return;
  }
  let s = parser.createSVG();
  let valid = parser.validateSVGimage(s, __dirname + "/parser/svg.xsd");
  if (valid == 1) {
    let saved = parser.writeSVGimage(s, __dirname + "/uploads/" + req.query.filename);
    parser.deleteSVGimage(s);
    try{
      let [rows, feilds] = await connection.execute("select file_name from FILE where file_name='" + req.query.filename + "'");
      if (rows.length == 0) {
        await connection.execute("insert into FILE (file_name, file_title, file_description, n_rect, n_circ, n_path, n_group, creation_time, file_size) values ('" + req.query.filename + "','', '', 0, 0, 0, 0, NOW(), 0)");
      }
    } catch(e) {
      console.log("Query error: "+e);
    }
    if (saved == 1) {
      res.send({
        status : 1
      });
    } else {
      res.send({
        status: 0
      });
    }
  } else{
    parser.deleteSVGimage(s);
    res.send ({
      status : 0
    });
  }
});

app.get('/add-rect', function(req, res) {
  console.log(req.query.filename);
  let rect = {
    x: parseFloat(req.query.x),
    y: parseFloat(req.query.y),
    w: parseFloat(req.query.w),
    h: parseFloat(req.query.h),
    units: req.query.units
  }
  console.log(JSON.stringify(rect));
  let srect = parser.JSONtoRect(JSON.stringify(rect));
  let s = parser.createValidSVGimage(__dirname+"/uploads/" + req.query.filename, __dirname + "/parser/svg.xsd");
  //let srect = parser.createRect(parseFloat(req.query.x), parseFloat(req.query.y), parseFloat(req.query.w), parseFloat(req.query.h), req.query.units);
  //console.log(parser.rectangleToString(srect));
  parser.addComponent(s, 2, srect);
  let valid = parser.validateSVGimage(s, __dirname + "/parser/svg.xsd");
  if (valid == 1) {
    let saved = parser.writeSVGimage(s, __dirname + "/uploads/" + req.query.filename);
    parser.deleteSVGimage(s);
    if (saved == 1) {
      changes(req.query.filename, "Add rectangle", "add rectangle at " + rect.x + ", " + rect.y + " height: " + rect.h + " and width: " + rect.w);
      res.send({
        status : 1
      });
    } else {
      res.send({
        status: 0
      });
    }
  } else{
    parser.deleteSVGimage(s);
    res.send ({
      status : 0
    });
  }
});

app.get('/add-circ', function(req, res) {
  //console.log(req.query.filename);
  let circ = {
    cx: parseFloat(req.query.x),
    cy: parseFloat(req.query.y),
    r: parseFloat(req.query.r),
    units: req.query.units
  }
  //console.log(JSON.stringify(circ));
  let srect = parser.JSONtoCircle(JSON.stringify(circ));
  let s = parser.createValidSVGimage(__dirname+"/uploads/" + req.query.filename, __dirname + "/parser/svg.xsd");
  //let srect = parser.createRect(parseFloat(req.query.x), parseFloat(req.query.y), parseFloat(req.query.w), parseFloat(req.query.h), req.query.units);
  //console.log(parser.rectangleToString(srect));
  parser.addComponent(s, 1, srect);
  let valid = parser.validateSVGimage(s, __dirname + "/parser/svg.xsd");
  if (valid == 1) {
    let saved = parser.writeSVGimage(s, __dirname + "/uploads/" + req.query.filename);
    parser.deleteSVGimage(s);
    if (saved == 1) {
      changes(req.query.filename, "Add circle", "add cicle at " + circ.cx + ", " + circ.cy + " radius: " + circ.r);
      res.send({
        status : 1
      });
    } else {
      res.send({
        status: 0
      });
    }
  } else{
    parser.deleteSVGimage(s);
    res.send ({
      status : 0
    });
  }
});

app.get('/scale-rects', function(req, res) {
  console.log(req.query.filename);
  //let srect = parser.JSONtoCircle(JSON.stringify(circ));
  let s = parser.createValidSVGimage(__dirname+"/uploads/" + req.query.filename, __dirname + "/parser/svg.xsd");
  parser.scaleRects(s, parseFloat(req.query.scale));
  //let srect = parser.createRect(parseFloat(req.query.x), parseFloat(req.query.y), parseFloat(req.query.w), parseFloat(req.query.h), req.query.units);
  //console.log(parser.rectangleToString(srect));
  //parser.addComponent(s, 1, srect);
  let valid = parser.validateSVGimage(s, __dirname + "/parser/svg.xsd");
  if (valid == 1) {
    let saved = parser.writeSVGimage(s, __dirname + "/uploads/" + req.query.filename);
    parser.deleteSVGimage(s);
    if (saved == 1) {
      res.send({
        status : 1
      });
    } else {
      res.send({
        status: 0
      });
    }
  } else{
    parser.deleteSVGimage(s);
    res.send ({
      status : 0
    });
  }
});

app.get('/scale-circs', function(req, res) {
  console.log(req.query.filename);
  //let srect = parser.JSONtoCircle(JSON.stringify(circ));
  let s = parser.createValidSVGimage(__dirname+"/uploads/" + req.query.filename, __dirname + "/parser/svg.xsd");
  parser.scaleCircs(s, parseFloat(req.query.scale));
  //let srect = parser.createRect(parseFloat(req.query.x), parseFloat(req.query.y), parseFloat(req.query.w), parseFloat(req.query.h), req.query.units);
  //console.log(parser.rectangleToString(srect));
  //parser.addComponent(s, 1, srect);
  let valid = parser.validateSVGimage(s, __dirname + "/parser/svg.xsd");
  if (valid == 1) {
    let saved = parser.writeSVGimage(s, __dirname + "/uploads/" + req.query.filename);
    parser.deleteSVGimage(s);
    if (saved == 1) {
      res.send({
        status : 1
      });
    } else {
      res.send({
        status: 0
      });
    }
  } else{
    parser.deleteSVGimage(s);
    res.send ({
      status : 0
    });
  }
});

app.get('/store-files', async function(req, res) {
  var dict = {};
  var files = fs.readdirSync(__dirname+'/uploads/');
  for (const file of files) {
    let c = parser.createValidSVGimage(__dirname+"/uploads/" + file, __dirname + "/parser/svg.xsd");
    let s = parser.SVGtoJSON(c);
    if (s != "{}") {
      try{
        let [rows, feilds] = await connection.execute("select file_name from FILE where file_name='" + file + "'");
        if (rows.length == 0) {
          let title = parser.getTitle(c);
          let descr = parser.getDesc(c);
          var info = JSON.parse(s);
          const stats = fs.statSync("uploads/" + file);
          const fileSizeInBytes = stats.size;
          await connection.execute("insert into FILE (file_name, file_title, file_description, n_rect, n_circ, n_path, n_group, creation_time, file_size) values ('" + file + "', '" + title + "', '" + descr + "', " + info.numRect + ", " + info.numCirc + ", " + info.numPaths + ", " + info.numGroups + ", NOW(), " + Math.round(fileSizeInBytes / 1000) +")");
        }
      } catch(e) {
        console.log("Query error: "+e);
        res.send({
          status : 0
        });
        parser.deleteSVGimage(c);
        return;
      }
    }
    parser.deleteSVGimage(c);
  }
  res.send({
    status : 1
  });
});

app.get('/clear-all', async function(req, res) {
  try {
    await connection.execute("delete from FILE");
    await connection.execute("delete from IMG_CHANGE");
    await connection.execute("delete from DOWNLOAD");
    res.send({
      status : 1
    });
  } catch(e) {
    console.log("Query error: "+e);
    res.send({
      status : 0
    });
  }
});

app.get('/status', async function(req, res) {
  var values = await status();
  //console.log(values);
  res.send({
    file: values[0],
    change: values[1],
    down: values[2]
  });
});

app.get('/downloaded', async function(req, res) {
  try {
    await connection.execute("insert into DOWNLOAD (d_descr, svg_id) select 'ip: " + req.connection.remoteAddress + "', svg_id from FILE where file_name='" + req.query.image + "'");
    res.send({
      status : 1
    });
  } catch(e) {
    console.log("Query error: "+e);
    res.send({
      status : 0
    });
  }
});

app.get('/display-all', async function(req, res) {
  try {
    let [rows, feilds] = await connection.execute("select * from FILE order by " + req.query.sort + " asc");
    res.send(rows);
  } catch(e) {
    console.log("Query error: "+e);
    res.send(0);
  }
});

app.get('/display-all-create', async function(req, res) {
  console.log(req.query.date1 + " " + req.query.date2);
  try {
    let [rows, feilds] = await connection.execute("select * from FILE where creation_time between '" + req.query.date1 + "' and '" + req.query.date2 + "'order by " + req.query.sort + " asc");
    res.send(rows);
  } catch(e) {
    console.log("Query error: "+e);
    res.send(0);
  }
});

app.get('/display-all-modified', async function(req, res) {
  console.log(req.query.date1 + " " + req.query.date2);
  try {
    let [rows, feilds] = await connection.execute("select distinct MAX(IMG_CHANGE.change_time), COUNT(*), FILE.file_name, FILE.file_size from IMG_CHANGE inner join FILE on IMG_CHANGE.svg_id=FILE.svg_id where change_time between '" + req.query.date1 + "' and '" + req.query.date2 + "' group by FILE.svg_id order by " + req.query.sort);
    res.send(rows);
  } catch(e) {
    console.log("Query error: "+e);
    res.send(0);
  }
});

app.get('/login', async function(req, res) {
  let dbConf = {
  	host     : 'dursley.socs.uoguelph.ca',
  	user     : req.query.username,
  	password : req.query.password,
  	database : req.query.database
  };
  try{
      connection = await mysql.createConnection(dbConf)

      let [rows, feilds] =  await connection.execute("select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_NAME = 'FILE'");

      if (rows.length == 0) {
        await connection.execute("CREATE TABLE FILE (svg_id INT AUTO_INCREMENT PRIMARY KEY, file_name VARCHAR(60) NOT NULL, file_title VARCHAR(256), file_description VARCHAR(256), n_rect INT NOT NULL, n_circ INT NOT NULL, n_path INT NOT NULL, n_group INT NOT NULL, creation_time DATETIME NOT NULL, file_size INT NOT NULL)");
      }

      [rows, feilds] =  await connection.execute("select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_NAME = 'IMG_CHANGE'")

      if (rows.length == 0) {
        await connection.execute("CREATE TABLE IMG_CHANGE (change_id INT AUTO_INCREMENT PRIMARY KEY, change_type VARCHAR(256) NOT NULL, change_summary VARCHAR(256), change_time DATETIME NOT NULL, svg_id INT NOT NULL, FOREIGN KEY(svg_id) REFERENCES FILE(svg_id) ON DELETE CASCADE)");
      }

      [rows, feilds] =  await connection.execute("select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_NAME = 'DOWNLOAD'");

      if (rows.length == 0) {
        await connection.execute("CREATE TABLE DOWNLOAD (download_id INT AUTO_INCREMENT PRIMARY KEY, d_descr VARCHAR(256), svg_id INT NOT NULL, FOREIGN KEY(svg_id) REFERENCES FILE(svg_id) ON DELETE CASCADE)");
      }
      res.send({
        status : 1
      });
  }catch(e){
      console.log("Query error: "+e);
      res.send({
        status : 0
      });
  }//finally {
    //  if (connection && connection.end) connection.end();
  //}
});

async function status() {
  var file, down, change;
  try {
    let [rows, feilds] = await connection.execute("select * from FILE");
    file = rows.length;
    [rows, feilds] = await connection.execute("select * from DOWNLOAD");
    down = rows.length;
    [rows, feilds] = await connection.execute("select * from IMG_CHANGE");
    change = rows.length;
  } catch(e) {
    console.log("Query error: "+e);
  }
  return [file, change, down];
}

async function changes(file, type, summary) {
  try {
    await connection.execute("insert into IMG_CHANGE (change_type, change_summary, change_time, svg_id) select \"" + type + "\", " + connection.escape(summary) + ", NOW(), svg_id from FILE where file_name=\"" + file + "\"");
  } catch(e) {
    console.log("Query error: "+e);
  }
}

app.listen(portNum);
console.log('Running app at localhost: ' + portNum);
