// Put all onload AJAX calls here, and event listeners
$(document).ready(function() {
    // On page-load AJAX Example

    $('#login-modal').modal({
      keyboard: false,
      backdrop: 'static'
    })
    //$('#login-modal').modal()

    $.ajax({
        type: 'get',
        dataType: 'json',
        url: '/images',
        success: function (data) {
          if (Object.keys(data).length == 0) {
            $("#file-log-table").append("<tr><td colspan=\"7\"> No files uploaded</td></tr>");
            $('#store-btn').hide();
          }
          if (Object.keys(data).length > 5) {
            $("#file-log-panel").attr("style", "height:800px;overflow:auto;");
          }
          for(i in data){
            var row = $("#file-log-table").append(
              "<tr>" +
                "<td><a href=" + i + " onclick=\"downloaded('" + i +"')\" download><img src=" + i + " width=\"200px\"></a></td>" +
                "<td><a download="+ i +" onClick=\"downloaded(" + i + ")\" href=" + i + ">" + i + "</a></td>" +
                "<td>" + data[i]["size"] + "</td>" +
                "<td>" + data[i]["numRect"] + "</td>" +
                "<td>" + data[i]["numCirc"] + "</td>" +
                "<td>" + data[i]["numPaths"] + "</td>" +
                "<td>" + data[i]["numGroups"] + "</td>" +
              "</tr>"
            );
            $('#images-list').append($('<option>', {
              value: i,
              text: i
            }));
          }
          console.log(data);
        },
        fail: function(error) {
            // Non-200 return, do something with error
            //$('#blah').html("On page load, received error from server");
            alert(error);
        }
    });

    $('#images-list').change(function(){
      $.ajax({
          type: 'get',
          dataType: 'json',
          url: '/viewpanel',
          data: {
              file: $('#images-list option:selected').text()
          },
          success: function (data) {
            $("#image-img").html("<img src=\"" + $('#images-list option:selected').text() + "\" width=\"800px\">");
            $("#image-title").html(data["title"]);
            $("#image-desc").html(data["description"]);
            $("#edit-title").attr("placeholder", data["title"]);
            $("#edit-description").attr("placeholder", data["description"]);
            $("#view-table-foot").html(" ");
            $("#images-list-edit").html(" ");
            for (var i = 0; i < data["rectangles"].length; i++) {
              let attrs = '|';
              for (var j = 0; j < data["rectangles"][i]["attrs"].length; j++){
                attrs += data["rectangles"][i]["attrs"][j]["name"] + ": " + data["rectangles"][i]["attrs"][j]["value"] + "| ";
              }
              $("#view-table-foot").append(
                "<tr>" +
                  "<td>Rectangle " + (i+1) + "</td>" +
                  "<td>Upper left corner: x = " + data["rectangles"][i]["x"]+data["rectangles"][i]["units"] + ", y = " +
                  data["rectangles"][i]["y"]+data["rectangles"][i]["units"] + ", Width: " + data["rectangles"][i]["w"] +
                  data["rectangles"][i]["units"] + ", Height: " + data["rectangles"][i]["h"]+data["rectangles"][i]["units"] + "</td>" +
                  "<td>" + "<button class=\"btn btn-outline-info\" id=\"rb"+(i+1)+ "\" onClick=\"reply_click(this)\">" + data["rectangles"][i]["numAttr"] + "</button>" +
                  "<p id=\"rb" + (i+1) + "p\" style=\"display: none\">"+ attrs + "</p></td>" +
                "</tr>"
              );
              $('#images-list-edit').append($('<option>', {
                value: "Rectangle " + (i+1),
                text: "Rectangle " + (i+1)
              }));
            }
            for (var i = 0; i < data["circles"].length; i++) {
              let attrs = '|';
              for (var j = 0; j < data["circles"][i]["attrs"].length; j++){
                attrs += data["circles"][i]["attrs"][j]["name"] + ": " + data["circles"][i]["attrs"][j]["value"] + "| ";
              }
              $("#view-table-foot").append(
                "<tr>" +
                  "<td>Circle " + (i+1) + "</td>" +
                  "<td>Centre: x = " + data["circles"][i]["cx"]+data["circles"][i]["units"] + ", y = " +
                  data["circles"][i]["cy"]+data["circles"][i]["units"] + ", radius = " + data["circles"][i]["r"] +
                  data["circles"][i]["units"] + "</td>" +
                  "<td>" + "<button class=\"btn btn-outline-info\" id=\"cb"+(i+1)+ "\" onClick=\"reply_click(this)\">" + data["circles"][i]["numAttr"] + "</button>" +
                  "<p id=\"cb" + (i+1) + "p\" style=\"display: none\">"+ attrs + "</p></td>" +
                "</tr>"
              );
              $('#images-list-edit').append($('<option>', {
                value: "Circle " + (i+1),
                text: "Circle " + (i+1)
              }));
            }
            for (var i = 0; i < data["paths"].length; i++) {
              let attrs = '|';
              for (var j = 0; j < data["paths"][i]["attrs"].length; j++){
                attrs += data["paths"][i]["attrs"][j]["name"] + ": " + data["paths"][i]["attrs"][j]["value"] + "| ";
              }
              $("#view-table-foot").append(
                "<tr>" +
                  "<td>Path " + (i+1) + "</td>" +
                  "<td>path data = " + data["paths"][i]["d"] + "</td>" +
                  "<td>" + "<button class=\"btn btn-outline-info\" id=\"pb"+(i+1)+ "\" onClick=\"reply_click(this)\">" + data["paths"][i]["numAttr"] + "</button>" +
                  "<p id=\"pb" + (i+1) + "p\" style=\"display: none\">"+ attrs + "</p></td>" +
                "</tr>"
              );
              $('#images-list-edit').append($('<option>', {
                value: "Path " + (i+1),
                text: "Path " + (i+1)
              }));
            }
            for (var i = 0; i < data["groups"].length; i++) {
              let attrs = '|';
              for (var j = 0; j < data["groups"][i]["attrs"].length; j++){
                attrs += data["groups"][i]["attrs"][j]["name"] + ": " + data["groups"][i]["attrs"][j]["value"] + "| ";
              }
              $("#view-table-foot").append(
                "<tr>" +
                  "<td>Group " + (i+1) + "</td>" +
                  "<td>" + data["groups"][i]["children"] + " child elements</td>" +
                  "<td>" + "<button class=\"btn btn-outline-info\" id=\"gb"+(i+1)+ "\" onClick=\"reply_click(this)\">" + data["groups"][i]["numAttr"] + "</button>" +
                  "<p id=\"gb" + (i+1) + "p\" style=\"display: none\">"+ attrs + "</p></td>" +
                "</tr>"
              );
              $('#images-list-edit').append($('<option>', {
                value: "Group " + (i+1),
                text: "Group " + (i+1)
              }));
            }
            console.log(data);
          },
          fail: function(error) {
              //$('#blah').html("On page load, received error from server");
              alert(error);
          }
    });
  });

    $('#edit-title-button').click(function(){
        $.ajax({
            type: 'get',
            dataType: 'json',
            url: '/edit-title',
            data: {
                title: $("#edit-title").val(),
                image: $('#images-list option:selected').text()
            },
            success: function (data) {
              if (data["status"]==1) {
                display_status();
                location.reload(true);
              } else {
                alert("Something went wrong, Not saved!");
              }
              console.log(data);
            },
            fail: function(error) {
                console.log(error);
            }
        });
    });

    $('#edit-description-button').click(function(){
        $.ajax({
            type: 'get',
            dataType: 'json',
            url: '/edit-description',
            data: {
                description: $("#edit-description").val(),
                image: $('#images-list option:selected').text()
            },
            success: function (data) {
              if (data["status"]==1) {
                display_status();
                location.reload(true);
              } else {
                alert("Something went wrong, Not saved!");
              }
              console.log(data);
            },
            fail: function(error) {
                console.log(error);
            }
        });
    });

    $('#filename-button').click(function(){
        $.ajax({
            type: 'get',
            dataType: 'json',
            url: '/create-file',
            data: {
                filename: $("#filename").val()
            },
            success: function (data) {
              if (data["status"]==1) {
                display_status();
                location.reload(true);
              } else {
                alert("Filename not valid or file already exists, Not saved!");
              }
              console.log(data);
            },
            fail: function(error) {
                console.log(error);
            }
        });
    });

    $('#rect-button').click(function(){
        $.ajax({
            type: 'get',
            dataType: 'json',
            url: '/add-rect',
            data: {
                x: $("#rect-x").val(),
                y: $("#rect-y").val(),
                w: $("#rect-w").val(),
                h: $("#rect-h").val(),
                units: $("#rect-u").val(),
                filename: $('#images-list option:selected').text()
            },
            success: function (data) {
              if (data["status"]==1) {
                display_status();
                location.reload(true);
              } else {
                alert("Rectangle no valid, Not saved!");
              }
              console.log(data);
            },
            fail: function(error) {
                console.log(error);
            }
        });
    });

    $('#circ-button').click(function(){
        $.ajax({
            type: 'get',
            dataType: 'json',
            url: '/add-circ',
            data: {
                x: $("#circ-x").val(),
                y: $("#circ-y").val(),
                r: $("#circ-r").val(),
                units: $("#circ-u").val(),
                filename: $('#images-list option:selected').text()
            },
            success: function (data) {
              if (data["status"]==1) {
                display_status();
                location.reload(true);
              } else {
                alert("Circle no valid, Not saved!");
              }
              console.log(data);
            },
            fail: function(error) {
                console.log(error);
            }
        });
    });

    $('#scale-rect-button').click(function(){
        $.ajax({
            type: 'get',
            dataType: 'json',
            url: '/scale-rects',
            data: {
                scale: $("#scale-rect").val(),
                filename: $('#images-list option:selected').text()
            },
            success: function (data) {
              if (data["status"]==1) {
                location.reload(true);
              } else {
                alert("Not scaled, Not saved!");
              }
              console.log(data);
            },
            fail: function(error) {
                console.log(error);
            }
        });
    });

    $('#scale-circ-button').click(function(){
        $.ajax({
            type: 'get',
            dataType: 'json',
            url: '/scale-circs',
            data: {
                scale: $("#scale-circ").val(),
                filename: $('#images-list option:selected').text()
            },
            success: function (data) {
              if (data["status"]==1) {
                location.reload(true);
              } else {
                alert("Not scaled, Not saved!");
              }
              console.log(data);
            },
            fail: function(error) {
                console.log(error);
            }
        });
    });

    $('#edit-form').submit(function(e){
      e.preventDefault();
      let selected = $('#images-list-edit option:selected').text();
      if (selected == "Attributes" || $('#edit-name').val() == '' || $('#edit-name').val() == '') {
        alert("No attrs picked or feild is missing!");
        return;
      }
      var shape = selected.split(" ");

      $.ajax({
          type: 'get',
          dataType: 'json',
          url: '/edit',
          data: {
              index: shape[1]-1,
              shape: shape[0],
              image: $('#images-list option:selected').text(),
              name: $('#edit-name').val(),
              value: $('#edit-value').val()
          },
          success: function (data) {
            console.log(data);
            if (data["status"]==1) {
              display_status();
              location.reload(true);
            } else {
              alert("Change didnt validate, not saved!")
            }
          },
          fail: function(error) {
              console.log(error);
          }
      });
    });

    $('#login-form').submit(function(e){
      e.preventDefault();

      $.ajax({
          type: 'get',
          dataType: 'json',
          url: '/login',
          data: {
              username: $('#username').val(),
              password: $('#password').val(),
              database: $('#database').val()
          },
          success: function (data) {
            console.log(data);
            if (data["status"]==1) {
              $('#login-modal').modal('hide');
            } else {
              //alert("Change didnt validate, not saved!")
              $('#login-form').append("Error: try again");
            }
          },
          fail: function(error) {
              console.log(error);
          }
      });
    });

    $('#store-btn').click(function(){
        $.ajax({
            type: 'get',
            dataType: 'json',
            url: '/store-files',
            data: {},
            success: function (data) {
              if (data["status"]==1) {
                display_status();
                //location.reload(true);
              } else {
                alert("Not stored!");
              }
              console.log(data);
            },
            fail: function(error) {
                console.log(error);
            }
        });
    });

    $('#clear-btn').click(function(){
        $.ajax({
            type: 'get',
            dataType: 'json',
            url: '/clear-all',
            data: {},
            success: function (data) {
              if (data["status"]==1) {
                display_status();
              } else {
                alert("Not cleared!");
              }
              console.log(data);
            },
            fail: function(error) {
                console.log(error);
            }
        });
    });

    $('#status-btn').click(function(){
        display_status();
    });

    $('#da-execute').click(function(){
        $.ajax({
            type: 'get',
            dataType: 'json',
            url: '/display-all',
            data: {
              sort: $("input[name='da-sort']:checked").val()
            },
            success: function (data) {
              //console.log(data);
              $('#display-all').html("<tr class=\"table-warning\"><th>File name</th><th>Title</th><th>Description</th><th>Num Rects</th><th>Num Circs</th><th>Num Paths</th><th>Num Groups</th><th>Time created</th><th>File Size</th></tr>");
              for (row in data) {
                $('#display-all').append("<tr><td>" + data[row]["file_name"] + "</td><td>" + data[row]["file_title"] + "</td><td>" + data[row]["file_description"] + "</td><td>" + data[row]["n_rect"] +"</td><td>" + data[row]["n_circ"] + "</td><td>" + data[row]["n_path"] + "</td><td>" + data[row]["n_group"] + "</td><td>" + data[row]["creation_time"] + "</td><td>" + data[row]["file_size"] + "</td></tr>");
              }
            },
            fail: function(error) {
                console.log(error);
            }
        });
    });

    $('#dac-execute').click(function(){
        $.ajax({
            type: 'get',
            dataType: 'json',
            url: '/display-all-create',
            data: {
              date1: $("#dac-date-1").val(),
              date2: $("#dac-date-2").val(),
              sort: $("input[name='dac-sort']:checked").val()
            },
            success: function (data) {
              //console.log(data);
              $('#display-all-created').html("<tr class=\"table-warning\"><th>File name</th><th>Title</th><th>Description</th><th>Num Rects</th><th>Num Circs</th><th>Num Paths</th><th>Num Groups</th><th>Time created</th><th>File Size</th></tr>");
              for (row in data) {
                $('#display-all-created').append("<tr><td>" + data[row]["file_name"] + "</td><td>" + data[row]["file_title"] + "</td><td>" + data[row]["file_description"] + "</td><td>" + data[row]["n_rect"] +"</td><td>" + data[row]["n_circ"] + "</td><td>" + data[row]["n_path"] + "</td><td>" + data[row]["n_group"] + "</td><td>" + data[row]["creation_time"] + "</td><td>" + data[row]["file_size"] + "</td></tr>");
              }
            },
            fail: function(error) {
                console.log(error);
            }
        });
    });

    $('#dam-execute').click(function(){
        $.ajax({
            type: 'get',
            dataType: 'json',
            url: '/display-all-modified',
            data: {
              date1: $("#dam-date-1").val(),
              date2: $("#dam-date-2").val(),
              sort: $("input[name='dam-sort']:checked").val()
            },
            success: function (data) {
              //console.log(data);
              $('#display-all-modified').html("<tr class=\"table-warning\"><th>Recent modification date</th><th>Number of changes</th><th>File name</th><th>File size</th></tr>");
              for (row in data) {
                $('#display-all-modified').append("<tr><td>" + new Date(data[row]["MAX(IMG_CHANGE.change_time)"]).toString() + "</td><td>" + data[row]["COUNT(*)"] + "</td><td>" + data[row]["file_name"] + "</td><td>" + data[row]["file_size"] +"</td></tr>");
              }
            },
            fail: function(error) {
                console.log(error);
            }
        });
    });
});

function display_status() {
  $.ajax({
      async: false,
      type: 'get',
      dataType: 'json',
      url: '/status',
      data: {},
      success: function (data) {
        //console.log(data);
        alert("Database has " + data["file"] + " files, " + data["change"] + " changes, and " + data["down"] + " downloads");
      },
      fail: function(error) {
          console.log(error);
      }
  });
}

function reply_click(id) {
  console.log($('#' + (id.id)+'p').text());
  $('#' + (id.id)+'p').show("slow");
  id.remove();
}

function downloaded(img) {
  $.ajax({
      type: 'get',
      dataType: 'json',
      url: '/downloaded',
      data: {
          image: img
      },
      success: function (data) {
        console.log(data);
        if (data["status"]==1) {
          display_status();
        } else {
          alert("sumfin went rong");
        }
      },
      fail: function(error) {
          console.log(error);
      }
  });
}
